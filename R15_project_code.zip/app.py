"""Streamlit app: R15 Radiology Report Negation & Uncertainty Tagger (pleural effusion).
Educational prototype using FICTIONAL / synthetic text. Not for clinical use."""
import html, io, json, datetime as dt
import pandas as pd
import streamlit as st
import core

st.set_page_config(page_title="R15 Report Negation & Uncertainty Tagger", page_icon="🩻", layout="wide")

SAMPLE = ("Heart size is normal. There is a small right pleural effusion.\n"
          "No pneumothorax or left pleural effusion.\n"
          "Cannot exclude a trace effusion at the left base.\n"
          "The lungs are otherwise clear.")
COLORS = {"present": "#f8d7da", "absent": "#d4edda", "uncertain": "#fff3cd", "no mention": "#e9ecef"}


@st.cache_resource
def get_model():
    return core.load_model()


@st.cache_data
def get_metrics():
    try:
        return json.load(open(core.BASE / "results" / "metrics.json"))
    except Exception:
        return None


def set_sample():
    st.session_state["report_text"] = SAMPLE


def reset_all():
    st.session_state["report_text"] = ""


if "report_text" not in st.session_state:
    st.session_state["report_text"] = ""

model, how = get_model()
metrics = get_metrics()
threshold = metrics["review_threshold"] if metrics else 0.60

st.title("🩻 Radiology Report Negation & Uncertainty Tagger")
st.caption("Project R15 · HCT487 AI in Healthcare · target finding: **pleural effusion** · "
           "educational prototype on fictional text. Output requires human review.")

with st.sidebar:
    st.header("About this model")
    st.write(f"**Model version:** `{core.MODEL_VERSION}`")
    st.write(f"Model source: {how}")
    st.write(f"Low-confidence review threshold (default): **{threshold:.2f}**")
    if metrics:
        st.write(f"Held-out macro-F1: model **{metrics['final']['model']['macro_f1']:.2f}** vs keyword baseline "
                 f"**{metrics['final']['baseline']['macro_f1']:.2f}** (unseen synthetic wording).")
    st.subheader("Limitations")
    st.markdown(
        "- Trained on **synthetic fictional sentences**; results do **not** show clinical performance.\n"
        "- Handles one finding (pleural effusion) in English only.\n"
        "- Weak on double negation, 'no change', historical statements and unfamiliar hedging.\n"
        "- Confidence can be high even when wrong.\n"
        "- Gives status of mentions only: **no diagnosis, no recommendations**.\n"
        "- Do not paste real patient information.")

c1, c2, c3 = st.columns([1, 1, 4])
c1.button("Load sample case", on_click=set_sample)
c2.button("Reset", on_click=reset_all)

text = st.text_area("Paste report text (fictional only)", key="report_text", height=200,
                    placeholder="e.g. There is no pleural effusion. Possible small left effusion.")
run = st.button("Analyse", type="primary")

if run:
    ok, msg = core.validate_input(text)
    if not ok:
        st.error(msg)
    else:
        rows = core.analyse(text, model, threshold)
        df = pd.DataFrame(rows)
        n_found = int((df["status"] != "no mention").sum())
        if n_found == 0:
            st.warning("No mention of pleural effusion was found in this text, so nothing was classified.")
        st.subheader("Sentence-level results")
        for r in rows:
            label = r["status"].upper()
            extra = ""
            if r["confidence"] is not None:
                extra = f" · confidence {r['confidence']:.2f}"
                if r["review"]:
                    extra += " · ⚠️ low confidence, please review"
            sent = html.escape(r["sentence"])
            if r["mention"]:
                m = html.escape(r["mention"])
                sent = sent.replace(m, f"<mark>{m}</mark>", 1)
            st.markdown(
                f"<div style='background:{COLORS[r['status']]};color:#111;padding:8px 12px;border-radius:8px;margin-bottom:6px'>"
                f"<b>{label}</b>{extra}<br>{sent}</div>", unsafe_allow_html=True)
        st.caption("Highlighted words show the matched finding term. Statuses are suggestions for a human reviewer, "
                   "not diagnoses.")
        show = df[["n", "sentence", "mention", "status", "confidence", "review", "baseline"]].rename(
            columns={"baseline": "keyword_baseline"})
        with st.expander("Table view (model vs keyword baseline)"):
            st.dataframe(show, use_container_width=True)
        report = {"model_version": core.MODEL_VERSION, "created": dt.datetime.now().isoformat(timespec="seconds"),
                  "review_threshold": threshold, "input_text": text, "annotations": rows,
                  "disclaimer": "Educational prototype on synthetic data. Human review required."}
        d1, d2 = st.columns(2)
        d1.download_button("⬇️ Download annotations (CSV)", show.to_csv(index=False), "r15_annotations.csv", "text/csv")
        d2.download_button("⬇️ Download full report (JSON)", json.dumps(report, indent=2), "r15_report.json", "application/json")
