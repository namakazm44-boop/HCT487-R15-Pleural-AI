"""Shared logic for the R15 Radiology Report Negation & Uncertainty Tagger.
Finding of interest: pleural effusion. Labels: present / absent / uncertain.
"""
import re
from pathlib import Path

MODEL_VERSION = "r15-tfidf-cues-lr-v2.0"
LABELS = ["present", "absent", "uncertain"]
BASE = Path(__file__).parent
MODEL_PATH = BASE / "model" / "r15_model.joblib"
TRAIN_CSV = BASE / "data" / "train.csv"
TRAIN_CFG = dict(C=0.5, ngram=(1, 1), use_cues=True)  # overwritten by train_evaluate.py selection (see model/config.json)
MAX_CHARS = 5000

# ---- finding mention detector (the "target finding" = pleural effusion) ----
MENTION_RE = re.compile(
    r"(pleural\s+effusions?|pleural\s+fluid(\s+collections?)?|fluid\s+in\s+the\s+pleural\s+space|effusions?)",
    re.I)
SIDE_RE = re.compile(r"\b(left|right|bilateral|bilaterally)\b", re.I)
SIZE_RE = re.compile(r"\b(trace|tiny|small|moderate|large|mild|massive)\b", re.I)


def normalise(text: str) -> str:
    """Mask the finding term, side and size so the model learns the *status*
    wording (negation / hedging), not the vocabulary of one template."""
    t = text.lower()
    t = MENTION_RE.sub(" findingx ", t)
    t = SIDE_RE.sub(" sidex ", t)
    t = SIZE_RE.sub(" sizex ", t)
    t = re.sub(r"[^a-z\s]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


# ---- input validation ----
def validate_input(text):
    """Return (ok, message). Handles empty, non-text, too long, non-latin text."""
    if text is None or not isinstance(text, str):
        return False, "Input must be text."
    if not text.strip():
        return False, "Please enter or paste some report text."
    if len(text) > MAX_CHARS:
        return False, f"Text is too long ({len(text)} characters). Limit is {MAX_CHARS}."
    letters = sum(c.isalpha() for c in text)
    if letters < 3:
        return False, "Text contains too few letters to analyse."
    latin = sum(("a" <= c.lower() <= "z") for c in text if c.isalpha())
    if latin / max(letters, 1) < 0.7:
        return False, "This prototype supports English report text only."
    return True, "OK"


def split_sentences(text: str):
    """Split on full stops, question marks and line breaks (not semicolons)."""
    parts = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    return [p.strip() for p in parts if p and p.strip()]


# ---- rule baseline: keyword + negation/hedge cues ----
NEG_CUES = ["no", "without", "negative for", "absent", "absence of", "free of",
            "resolved", "resolution of", "not seen", "no longer", "clear of", "nil"]
HEDGE_CUES = ["possible", "possibly", "probable", "probably", "cannot exclude",
              "cannot be excluded", "may", "might", "suspicious", "questionable",
              "equivocal", "versus", "could", "suggest", "suggests", "question of",
              "differential", "unclear"]


def rule_baseline(sentence: str) -> str:
    """Keyword-and-negation baseline: look for the finding, then cue words in
    the same sentence. Hedge cues win over negation; otherwise 'present'."""
    s = sentence.lower()
    m = MENTION_RE.search(s)
    if not m:
        return "absent"
    for cue in HEDGE_CUES:
        if re.search(r"\b" + re.escape(cue) + r"\b", s):
            return "uncertain"
    pre = s[: m.start()]
    window = " ".join(pre.split()[-6:])
    for cue in NEG_CUES:
        if re.search(r"\b" + re.escape(cue) + r"\b", window):
            return "absent"
    post = s[m.end():]
    if re.search(r"\b(is|are|has been|was)\s+(absent|excluded|resolved)\b|\bno longer\b", post):
        return "absent"
    return "present"


# ---- cue-window features (used by the model as extra inputs; baseline uses them as hard rules) ----
def cue_features(texts):
    import numpy as np
    out = []
    for s in texts:
        s = s.lower()
        m = MENTION_RE.search(s)
        pre = s[: m.start()] if m else s
        window = " ".join(pre.split()[-6:])
        post = s[m.end():] if m else ""
        neg_pre = any(re.search(r"\b" + re.escape(c) + r"\b", window) for c in NEG_CUES)
        neg_any = any(re.search(r"\b" + re.escape(c) + r"\b", s) for c in NEG_CUES)
        hedge = any(re.search(r"\b" + re.escape(c) + r"\b", s) for c in HEDGE_CUES)
        post_neg = bool(re.search(r"\b(absent|excluded|resolved|none|not\s+(seen|present|visible|demonstrated)|no longer)\b", post))
        post_hedge = bool(re.search(r"\b(cannot|can not|not)\s+(be\s+)?(excluded|ruled out|entirely excluded|assessed|confidently)\b", post))
        any_cue = neg_pre or neg_any or hedge or post_neg or post_hedge
        out.append([neg_pre, neg_any, hedge, post_neg, post_hedge, not any_cue])
    return np.array(out, dtype=float)


# ---- model loading (falls back to retraining if pickle is incompatible) ----
def build_pipeline(C=5.0, ngram=(1, 3), use_cues=True):
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline, FeatureUnion
    from sklearn.preprocessing import FunctionTransformer
    tfidf = TfidfVectorizer(preprocessor=normalise, ngram_range=ngram, min_df=1, sublinear_tf=True)
    feats = tfidf if not use_cues else FeatureUnion([
        ("tfidf", tfidf), ("cues", FunctionTransformer(cue_features, validate=False))])
    return Pipeline([("feats", feats),
                     ("clf", LogisticRegression(C=C, max_iter=2000, class_weight="balanced"))])


def load_model():
    import joblib
    try:
        return joblib.load(MODEL_PATH), "loaded from file"
    except Exception:
        import pandas as pd
        df = pd.read_csv(TRAIN_CSV)
        pipe = build_pipeline(**TRAIN_CFG).fit(df["text"], df["label"])
        return pipe, "re-trained at start-up (saved model not compatible)"


def analyse(text, model, review_threshold):
    """Run the full pipeline on pasted report text. Returns list of dict rows."""
    rows = []
    for i, sent in enumerate(split_sentences(text), 1):
        m = MENTION_RE.search(sent)
        if not m:
            rows.append(dict(n=i, sentence=sent, mention="", status="no mention",
                             confidence=None, review=False, baseline="-"))
            continue
        proba = model.predict_proba([sent])[0]
        k = int(proba.argmax())
        conf = float(proba[k])
        rows.append(dict(n=i, sentence=sent, mention=m.group(0), status=model.classes_[k],
                         confidence=conf, review=conf < review_threshold,
                         baseline=rule_baseline(sent),
                         p_present=float(proba[list(model.classes_).index("present")]),
                         p_absent=float(proba[list(model.classes_).index("absent")]),
                         p_uncertain=float(proba[list(model.classes_).index("uncertain")])))
    return rows
