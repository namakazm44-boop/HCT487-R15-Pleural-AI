"""Missing / invalid / unsupported input tests + a few behaviour checks. Run: python input_tests.py"""
import pandas as pd, core
model, _ = core.load_model()
cases = [
 ("empty string", ""), ("whitespace only", "   \n  "), ("None", None), ("numbers only", "12345 67890"),
 ("arabic text", "لا يوجد انصباب جنبي"), ("too long", "No pleural effusion. " * 400),
 ("no mention of finding", "The heart size is normal. The lungs are clear."),
 ("unrelated text", "The weather is sunny and I like football."),
 ("normal absent", "No pleural effusion."), ("normal present", "There is a large left pleural effusion."),
 ("normal uncertain", "Possible small right effusion."), ("multi-sentence", "No pneumothorax. Small effusion on the left."),
 ("double negation (known weakness)", "There is no doubt that a pleural effusion is present."),
]
rows = []
for name, txt in cases:
    ok, msg = core.validate_input(txt)
    if not ok:
        rows.append(dict(case=name, accepted=False, result=msg)); continue
    res = core.analyse(txt, model, 0.6)
    rows.append(dict(case=name, accepted=True,
                     result="; ".join(f"{r['status']}" + (f" ({r['confidence']:.2f})" if r['confidence'] else "") for r in res)))
df = pd.DataFrame(rows); df.to_csv("results/input_tests.csv", index=False); print(df.to_string())
