"""Synthetic generator for R15 (fictional report sentences about pleural effusion).
Every sentence is fictional. Labels come from the template family that produced it.
Splits are made BY TEMPLATE FAMILY, so test wording is never seen in training.
Run: python generate_data.py
"""
import random, csv, json
from pathlib import Path

random.seed(487)
T_SING = ["pleural effusion", "effusion", "pleural fluid collection"]      # takes "a"
T_ANY = ["pleural effusion", "pleural effusions", "effusion", "pleural fluid"]  # no article
SIDE = ["left", "right", "bilateral"]
LR = ["left", "right"]
CTX = ["", "", "On today's study, ", "Chest PA: ", "Portable film shows: ", "Lungs: ", "Pleural spaces: ", "Compared with yesterday, ", "Upright view: "]
SIZE = ["small", "moderate", "large", "trace", "tiny"]

# family -> (label, split, [templates]); slots: {side} {lr} {size} {ts} {ta}
FAMILIES = {
 # ---------------- PRESENT ----------------
 "P1_direct":        ("present", "train", ["There is a {size} {side} {ts}.", "A {size} {side} {ts} is present.", "Chest radiograph shows a {size} {side} {ts}.", "A {side} {ts} is identified."]),
 "P2_consistent":    ("present", "train", ["Findings are consistent with a {size} {side} {ts}.", "Appearances are in keeping with a {side} {ts}.", "The study demonstrates a {size} {ts} on the {lr}."]),
 "P3_interval":      ("present", "train", ["The {side} {ts} has increased in size compared with the prior study.", "Interval enlargement of the {size} {side} {ts}.", "Persistent {side} {ts}, unchanged from before."]),
 "P4_blunting":      ("present", "train", ["Blunting of the {lr} costophrenic angle due to {ts}.", "Layering fluid at the {lr} base consistent with {ts}.", "Meniscus sign at the {lr} lung base indicating {ts}."]),
 "P5_compound":      ("present", "train", ["No pneumothorax, but there is a {size} {side} {ts}.", "Lungs are otherwise clear apart from a {size} {side} {ts}.", "Heart size is normal; a {size} {side} {ts} is present.", "{size} {side} {ts} with adjacent atelectasis."]),
 "P6_impression":    ("present", "val",   ["Impression: {size} {side} {ts}.", "Pleural space: {size} {side} {ts} present."]),
 "P7_passive":       ("present", "test",  ["{side} {ts} is noted.", "A {ts} is evident on the {lr}.", "{ts} is visible at the {lr} base."]),
 "P8_followup":      ("present", "test",  ["Known {side} {ts} remains visible.", "Previously documented {ts} on the {lr} persists.", "Re-demonstration of the {size} {ts} on the {lr}."]),
 "P9_causal":        ("present", "test",  ["The {side} {ts} accounts for the basal opacity.", "Opacification of the {lr} hemithorax is explained by a large {ts}.", "{ts} is responsible for the {lr} basal opacity."]),
 # ---------------- ABSENT ----------------
 "A1_no_direct":     ("absent", "train", ["No {ta}.", "No evidence of {ta}.", "There is no {ta}.", "No {side} {ta} is seen.", "No {ta} is present.", "No {ta} identified."]),
 "A2_negative_for":  ("absent", "train", ["Negative for {ta}.", "{ta} is absent.", "Absence of {ta}.", "Without {ta}.", "Study is negative for {ta}.", "Free of {ta}."]),
 "A3_sharp_angles":  ("absent", "train", ["The costophrenic angles are sharp, with no {ta}.", "Clear costophrenic angles and no {ta}.", "Lung bases are clear without {ta}.", "Sharp costophrenic angles; no {ta}.", "No {ta} at either lung base."]),
 "A4_resolved":      ("absent", "train", ["The previously seen {side} {ts} has resolved.", "Interval resolution of the {side} {ts}.", "The {side} {ts} is no longer present.", "Complete resolution of the {ts}."]),
 "A5_list":          ("absent", "train", ["No pneumothorax or {ta}.", "No consolidation, {ta} or pneumothorax.", "No focal airspace disease, {ta}, or pneumothorax.", "No {ta} or pericardial effusion.", "No pneumothorax, consolidation or {ta}."]),
 "A6_free_of":       ("absent", "val",   ["The pleural spaces are free of {ta}.", "No significant {ta} is demonstrated.", "No large {ta}.", "No {size} {ta} is seen."]),
 "A7_excluded":      ("absent", "test",  ["{ta} has been excluded.", "There is no radiographic sign of {ta}.", "No convincing {ta}."]),
 "A8_not_seen":      ("absent", "test",  ["{ta} is not seen.", "{ta} is not demonstrated on this study.", "No {ta} can be identified.", "{ta} is not visible."]),
 "A9_terse":         ("absent", "test",  ["Pleural surfaces unremarkable, specifically no {ta}.", "Nil {ta}.", "{ta}: none.", "No sign of {ta}.", "{ta} not present."]),
 # ---------------- UNCERTAIN ----------------
 "U1_possible":      ("uncertain", "train", ["Possible {size} {side} {ts}.", "There is a possible {side} {ts}.", "Probable small {side} {ts}."]),
 "U2_cannot_exclude":("uncertain", "train", ["Cannot exclude a {size} {side} {ts}.", "A small {ts} cannot be excluded.", "{ts} cannot be entirely excluded."]),
 "U3_may_be":        ("uncertain", "train", ["A {side} {ts} may be present.", "There may be a {ts} on the {lr}.", "Findings might represent a {ts}."]),
 "U4_versus":        ("uncertain", "train", ["Opacity at the {lr} base may represent {ts} or atelectasis.", "{lr} basal blunting: {ts} versus pleural thickening.", "Differential includes {ts} and consolidation."]),
 "U5_suspicious":    ("uncertain", "train", ["Suspicious for a {side} {ts}.", "Questionable {ts} on the {lr}.", "Equivocal {side} {ts}."]),
 "U6_suggest":       ("uncertain", "val",   ["Appearances suggest a small {ts} but are not definitive.", "Raises the possibility of {ts}.", "Appearances may reflect a {ts}.", "Cannot be certain whether a {ts} is present.", "Question of a small {ts}."]),
 "U7_consideration": ("uncertain", "test",  ["Subtle {lr} basal haze; {ts} is a consideration.", "Unclear whether there is a {ts}.", "Indeterminate for {ts}.", "{ts} not excluded on this film.", "A {ts} is possible."]),
 "U8_limited":       ("uncertain", "test",  ["Limited assessment for {ts} due to patient rotation.", "{ts} is difficult to evaluate on this projection."]),
 # ---------------- CHALLENGE (hard cases, test only, reported separately) ----------------
 "C1_double_negation":("present", "challenge", ["There is no doubt that a {size} {side} {ts} is present.", "The {ts} is not absent.", "It would be wrong to say there is no {ts}."]),
 "C2_negated_change": ("present", "challenge", ["No interval change in the {side} {ts}.", "No reduction in the {size} {lr} {ts}."]),
 "C3_historical":     ("absent",  "challenge", ["Prior {side} {ts} drained last month; none remains.", "Status post drainage of {side} {ts}, with no residual fluid.", "Previous {lr} {ts} no longer seen."]),
 "C4_hedged_no":      ("uncertain","challenge",["No definite {ts}, though a small amount cannot be ruled out.", "Not excluded: {lr} {ts}."]),
 # ---------------- FINAL TEST (written after the dev-test diagnosis; evaluated once, never tuned on) ----------------
 "F1_present_evidence":  ("present", "final", ["The {ts} is clearly seen on the {lr}.", "{ts} is demonstrated at the {lr} base.", "Evidence of a {size} {ts}."]),
 "F2_absent_neither":    ("absent", "final", ["The {lr} pleural space is clear; there is no {ta}.", "Neither {ta} nor pneumothorax is seen.", "Nothing to suggest {ta}."]),
 "F3_uncertain_open":    ("uncertain", "final", ["{ta} cannot be confidently assessed.", "Poorly evaluated for {ta}; follow-up may help.", "Findings leave open the possibility of {ta}."]),
}

def fill(t):
    s = t.format(side=random.choice(SIDE), lr=random.choice(LR), size=random.choice(SIZE),
                 ts=random.choice(T_SING), ta=random.choice(T_ANY))
    s = s[0].upper() + s[1:]
    ctx = random.choice(CTX)
    if ctx:
        s = ctx + s[0].lower() + s[1:]
        s = s[0].upper() + s[1:]
    return s

def main():
    rows, seen = [], set()
    per_template = {"train": 40, "val": 30, "test": 28, "challenge": 14, "final": 50}
    for fam, (label, split, temps) in FAMILIES.items():
        for t in temps:
            n, tries = 0, 0
            while n < per_template[split] and tries < 400:
                tries += 1
                s = fill(t)
                if s.lower() in seen:
                    continue
                seen.add(s.lower()); n += 1
                rows.append(dict(id=len(rows) + 1, text=s, label=label, split=split, family=fam, template=t))
    random.shuffle(rows)
    out = Path(__file__).parent / "data"
    out.mkdir(exist_ok=True)
    for split in ["train", "val", "test", "challenge", "final"]:
        part = [r for r in rows if r["split"] == split]
        with open(out / f"{split}.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(part[0].keys())); w.writeheader(); w.writerows(part)
    with open(out / "all_sentences.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    # leakage check: no template shared across splits
    tmpl = {}
    for r in rows:
        tmpl.setdefault(r["template"], set()).add(r["split"])
    assert all(len(v) == 1 for v in tmpl.values()), "template leakage across splits!"
    fam_split = {}
    for r in rows:
        fam_split.setdefault(r["family"], set()).add(r["split"])
    assert all(len(v) == 1 for v in fam_split.values()), "family leakage across splits!"
    summary = {s: {l: sum(1 for r in rows if r["split"] == s and r["label"] == l) for l in ["present", "absent", "uncertain"]}
               for s in ["train", "val", "test", "challenge", "final"]}
    json.dump(summary, open(out / "split_summary.json", "w"), indent=2)
    print(json.dumps(summary, indent=2)); print("total", len(rows))

if __name__ == "__main__":
    main()
