import json
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
m = json.load(open("results/metrics.json")); sp = json.load(open("data/split_summary.json"))
d = Document()
for s in d.sections: s.left_margin = s.right_margin = Inches(1); s.top_margin = s.bottom_margin = Inches(1)
st = d.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)

def H(t, l=1): d.add_heading(t, level=l)
def P(t, bold=False, italic=False):
    p = d.add_paragraph(); r = p.add_run(t); r.bold = bold; r.italic = italic; return p
def B(t): d.add_paragraph(t, style="List Bullet")
def T(rows, widths=None, header=True):
    t = d.add_table(rows=len(rows), cols=len(rows[0])); t.style = "Light Grid Accent 1"
    for i, row in enumerate(rows):
        for j, v in enumerate(row):
            c = t.cell(i, j); c.text = ""; run = c.paragraphs[0].add_run(str(v)); run.font.size = Pt(9.5); run.bold = (i == 0 and header)
    d.add_paragraph(); return t
def F(path, cap, w=6.0):
    d.add_picture(path, width=Inches(w)); d.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = P(cap, italic=True); p.alignment = WD_ALIGN_PARAGRAPH.CENTER

t = d.add_heading("Radiology Report Negation and Uncertainty Tagger", 0)
P("Project R15 · HCT487 AI in Healthcare · Technical Report", bold=True)
P("Student name: [YOUR NAME]    Student ID: [YOUR ID]    Instructor: Dr. Abbas Al-Zubaidi")
P("Target finding: pleural effusion   |   Model version: r15-tfidf-cues-lr-v2.0   |   Data: fictional synthetic sentences only")

H("1. Project brief")
T([["Item", "Description"],
   ["Project ID", "R15 – Radiology Report Negation and Uncertainty Tagger"],
   ["Problem", "Report sentences mentioning a finding can state it is present, absent or uncertain. Students (and simple keyword searches) confuse 'No effusion' with 'effusion'. The tool labels the status of each mention of one chosen chest finding (pleural effusion)."],
   ["Intended users", "Radiology students and teaching-file curators reviewing fictional report text."],
   ["Input", "Pasted report text (English, ≤ 5,000 characters)."],
   ["Output", "Sentence-level status (present / absent / uncertain / no mention), highlighted finding term, confidence, a low-confidence review flag, and exportable CSV/JSON annotations."],
   ["AI task", "3-class text classification: TF-IDF + cue-window features + logistic regression, compared with a keyword-and-negation rule baseline."],
   ["Minimum features", "Text box, sample case, reset, input checks, model version and limitations, downloadable result."]])

H("2. Clinical and workflow context")
P("Radiology reports are free text. Whether a finding is stated, denied or hedged changes its meaning completely, yet a plain keyword search treats 'No pleural effusion' and 'Large pleural effusion' the same. Negation and uncertainty detection is a standard step in report-mining work (e.g. NegEx, NegBio, the CheXpert labeler) [1–3]. This prototype is an educational tool that shows how a small supervised model handles the same problem and where it fails. It reports the status of a mention only; it does not diagnose, recommend management or decide causality, and all outputs need human review.")

H("3. Application design")
P("The app is a Streamlit page (app.py) backed by core.py. Workflow: (1) validate input (empty, non-text, too few letters, non-English, too long are rejected with a message); (2) split into sentences; (3) a regular-expression mention detector finds the target finding – sentences without it are reported as 'no mention' and never classified; (4) the model returns class probabilities; (5) predictions below a default review threshold (0.60) are flagged; (6) results are shown colour-coded with the finding highlighted and can be downloaded as CSV or JSON. A sample-case button, a reset button, the model version and a limitations panel are always visible. The keyword baseline prediction is shown in a table for comparison.")

H("4. Data")
P("No real reports were used. A transparent generator (generate_data.py, fixed seed 487) produces fictional sentences from templates. Each template belongs to a 'family' (a wording style, e.g. 'cannot exclude…' or 'no evidence of…'), and each family has a single label. Slots (side, size, finding term, short context prefix) are filled randomly. Labels are given by the family design: present = the finding is stated or still seen (including unchanged/persistent); absent = denied, resolved or not seen; uncertain = hedged, possible or not assessable.", )
P("Data dictionary: id (int), text (fictional sentence), label (present/absent/uncertain), split (train/val/test/challenge/final), family (template family), template (source template).")
P("Split design: splitting is by template family, not by random row, so wording in validation and test sets is never seen in training. The generator asserts that no template or family appears in more than one split.", bold=False)
rows = [["Split", "Present", "Absent", "Uncertain", "Total", "Purpose"]]
purp = {"train": "Fit models", "val": "Model selection and review threshold", "test": "Development test (used to diagnose v1 – see §5)", "challenge": "Hard cases: double negation, negated change, historical, hedged 'no'", "final": "New families written after diagnosis; evaluated once, never tuned on"}
for k in ["train", "val", "test", "challenge", "final"]:
    s = sp[k]; rows.append([k, s["present"], s["absent"], s["uncertain"], sum(s.values()), purp[k]])
T(rows)
P("Limitation of the data: because the sentences are template-generated, within-family wording is repetitive and the labels follow my own definitions. The data had to be reviewed by the instructor before submission ('instructor-reviewed' in the catalogue). Results show implementation skill on synthetic text, not clinical performance.", italic=True)

H("5. Methods")
B("Pre-processing: lower-casing; the finding term, side words (left/right/bilateral) and size words are masked (FINDINGX, SIDEX, SIZEX) so the model learns status wording rather than one vocabulary.")
B("Baseline: keyword-and-negation rules. Finds the finding term; a hedge cue (possible, may, cannot exclude, suggest, …) → uncertain; a negation cue within 6 words before the term (no, without, absent, resolved, …) or 'not seen/absent/excluded' after it → absent; otherwise present. This is a simplified NegEx-style approach [1].")
B("Model: TF-IDF word n-grams plus six cue-window binary features (negation before term, negation anywhere, hedge cue, post-term negation, post-term hedge, no cue at all), fed to class-balanced logistic regression.")
B("Model selection on the validation split only: 24 configurations (with/without cue features, C ∈ {0.5,1,5,20}, n-gram range 1–1, 1–2, 1–3). Selected: cue features on, C=0.5, unigrams (validation macro-F1 %.3f)." % m["validation_macro_f1"])
B("Review threshold: I searched validation data (0.40–0.95) for the lowest confidence giving ≥ 95%% accuracy on accepted items at ≥ 80%% coverage. No threshold reached that target (validation accuracy stayed at 0.84 at every threshold because the model was confident even when wrong), so a default of 0.60 was used. It is a default, not a validated operating point, and was not tuned on test data.")
B("Metrics: per-class precision, recall, F1, macro-F1, balanced accuracy, confusion matrices, bootstrap 95% CI (1,000 resamples) of the macro-F1 difference model − baseline. Resampling is per sentence, not per family, so the intervals are optimistic.")
P("Honest development history. Version 1 (TF-IDF only) was evaluated on the development test set and did worse than the baseline (macro-F1 0.545 vs 0.610) because, with no cue-word features, sentences without a familiar cue defaulted to arbitrary classes. I then added the cue features (v2), chosen on validation data. Because I had seen the test errors, the development test set is no longer a clean test, so I wrote three new families (the 'final' set) afterwards and evaluated them once. The final-set results are the most trustworthy numbers; the dev test and challenge set are reported for transparency.", bold=True)

H("6. Results")
def row(k, nm, lab): 
    r = m[k][nm]; return [lab, r["macro_f1"], r["balanced_acc"], r["accuracy"]]
rows = [["Set (n)", "System", "Macro-F1", "Balanced acc.", "Accuracy"]]
for k, lab in [("final", "Final – unseen families"), ("test", "Dev test"), ("challenge", "Challenge (hard)")]:
    for nm, sn in [("baseline", "Keyword baseline"), ("model", "TF-IDF+cues LR")]:
        r = m[k][nm]; rows.append([f"{lab} (n={m[k]['n']})", sn, f"{r['macro_f1']:.3f}", f"{r['balanced_acc']:.3f}", f"{r['accuracy']:.3f}"])
T(rows)
ci = m["final"]["f1_diff_ci95"]; ci2 = m["test"]["f1_diff_ci95"]; ci3 = m["challenge"]["f1_diff_ci95"]
P(f"On the final unseen families the model improved macro-F1 over the baseline by about {m['final']['model']['macro_f1']-m['final']['baseline']['macro_f1']:.2f} (bootstrap 95% CI {ci[0]:.2f} to {ci[1]:.2f}); on the dev test the gain was smaller ({ci2[0]:.2f} to {ci2[1]:.2f}); on the challenge set there was no improvement (CI {ci3[0]:.2f} to {ci3[1]:.2f}) – both systems are near or below chance on those hard constructions.")
rows = [["Final set, per class", "Baseline P / R / F1", "Model P / R / F1"]]
for l in ["present", "absent", "uncertain"]:
    b = m["final"]["baseline"]["report"][l]; mo = m["final"]["model"]["report"][l]
    rows.append([l, f"{b['precision']:.2f} / {b['recall']:.2f} / {b['f1-score']:.2f}", f"{mo['precision']:.2f} / {mo['recall']:.2f} / {mo['f1-score']:.2f}"])
T(rows)
F("results/confusion_final.png", "Figure 1. Confusion matrices on the final unseen families (rows = true class).")
F("results/accuracy_by_family.png", "Figure 2. Accuracy for each held-out template family: the model is strong on plain assertions and weak on unusual negation or hedging wording.")
P("Review flag (default threshold 0.60, not a validated operating point): on the final set no prediction fell below the 0.60 threshold (coverage 100%), and every model error had confidence ≥ 0.90. On the dev test, 47% of errors were flagged; on the challenge set 12%. Probabilities are therefore not reliable as a safety net for unfamiliar wording.")

H("7. Error analysis (selected cases from results/errors_*.csv)")
errs = [
 ["Subtle right basal haze; effusion is a consideration.", "uncertain", "present (0.99)", "'is a consideration' is a hedge never seen in training; no known cue, so the default is 'present'."],
 ["Limited assessment for pleural effusion due to patient rotation.", "uncertain", "present (0.99)", "'Not assessable' wording is outside the cue lists; model and baseline both miss it."],
 ["Neither pleural effusion nor pneumothorax is seen.", "absent", "present (0.99)", "'Neither/nor' construction and 'is seen' after the term mislead the model; baseline also fails."],
 ["Nothing to suggest pleural effusion.", "absent", "uncertain (0.99)", "The word 'suggest' is a hedge cue, but here it is negated – a scope error shared with the baseline."],
 ["There is no doubt that a large bilateral pleural effusion is present.", "present", "absent (0.98)", "Double negation: 'no' within the window before the term triggers 'absent'."],
 ["No reduction in the tiny right pleural effusion.", "present", "absent (0.98)", "'No' negates the change, not the finding – the model cannot separate negation scope."],
 ["No definite pleural effusion, though a small amount cannot be ruled out.", "uncertain", "absent (0.96)", "Leading 'No' dominates; the trailing 'cannot be ruled out' is outweighed."],
 ["Effusion: none.", "absent", "uncertain (0.57)", "Terse 'none' is rare in training; confidence is low, so the review flag correctly fires."],
 ["Prior left pleural effusion drained last month; none remains.", "absent", "uncertain (0.57)", "Historical mention; the model is unsure and flags it (baseline says 'present' with no flag)."],
]
T([["Sentence", "True", "Model (conf.)", "Why it failed (my interpretation)"]] + errs)
P("Patterns: (1) errors cluster on wording that is not in the cue lists or training families; (2) negation scope (double negation, 'no change', 'no doubt') is the clearest failure for both systems; (3) the model is much better than the baseline when a hedge is expressed in new words (e.g. 'open the possibility of') but only if some cue overlaps training. These are interpretations from reading the error files, not causal proofs.")

H("8. Missing, invalid and unsupported input tests (input_tests.py)")
import pandas as pd
it = pd.read_csv("results/input_tests.csv")
T([["Case", "Accepted", "Result"]] + [[r.case, "yes" if r.accepted else "no", r.result] for r in it.itertuples()])
P("Empty, whitespace, None, numbers-only, Arabic and over-length text are rejected with a clear message. Text without the finding returns 'no mention' instead of a forced class. The known double-negation weakness is visible in the last row.")

H("9. Limitations and improvement priorities")
B("Synthetic, template-based data: results do not predict performance on real reports; label rules are my own and need instructor review.")
B("One finding, English only, sentence-level only (no cross-sentence context such as 'Previously noted effusion…' in the next sentence).")
B("Negation scope is not modelled; double negation and 'no change' fail. Priority 1: add syntactic scope features or a dependency-based approach.")
B("Confidence is miscalibrated on unfamiliar wording. Priority 2: calibrate probabilities (Platt/isotonic) on a validation set containing novel families and abstain more aggressively.")
B("Priority 3: broaden and diversify training families, add noisy real-style variation, and have a second reviewer label a sample to estimate label agreement.")
B("Small number of held-out families (3 final, 3 dev, 4 challenge) – family-level variance is large; no claim of general superiority.")

H("10. Screenshots of an actual run")
P("[INSERT SCREENSHOT 1: app with the sample case loaded and results shown]", bold=True)
P("[INSERT SCREENSHOT 2: an invalid input (e.g. empty text) showing the error message]", bold=True)
P("[INSERT SCREENSHOT 3: download buttons and sidebar with model version and limitations]", bold=True)
P("(Replace these three lines with screenshots taken from your deployed or local app before submitting. I could not capture them for you.)", italic=True)

H("11. AI-use declaration")
P("[EDIT BEFORE SUBMISSION – state truthfully what you did.] AI assistant used: Claude (Anthropic) to draft the synthetic data generator, model training/evaluation code, Streamlit app, this report and the README. Verification: I ran generate_data.py, train_evaluate.py, input_tests.py and the app myself, checked the numbers in results/metrics.json against this report, and I can explain every step. No patient data and no API keys were used.")

H("References")
for r in ["[1] Chapman WW, Bridewell W, Hanbury P, Cooper GF, Buchanan BG. A simple algorithm for identifying negated findings and diseases in discharge summaries. J Biomed Inform. 2001;34(5):301–310.",
          "[2] Peng Y, Wang X, Lu L, Bagheri M, Summers R, Lu Z. NegBio: a high-performance tool for negation and uncertainty detection in radiology reports. AMIA Jt Summits Transl Sci Proc. 2018:188–196.",
          "[3] Irvin J, Rajpurkar P, Ko M, et al. CheXpert: a large chest radiograph dataset with uncertainty labels and expert comparison. Proc AAAI. 2019;33:590–597.",
          "[4] Pedregosa F, et al. Scikit-learn: machine learning in Python. J Mach Learn Res. 2011;12:2825–2830.",
          "[5] Streamlit documentation. https://docs.streamlit.io"]:
    P(r)
d.save("R15_Technical_Report.docx"); print("saved")
