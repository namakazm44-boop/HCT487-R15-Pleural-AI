# R15 – Radiology Report Negation & Uncertainty Tagger (HCT487)

Educational prototype. Classifies each sentence that mentions **pleural effusion** as
`present`, `absent` or `uncertain`. Uses **fictional synthetic text only**. Not for clinical use.

## Run the app
```bash
pip install -r requirements.txt
streamlit run app.py
```
Works offline. Demo input: `sample_input.txt` (or press **Load sample case**).
If `model/r15_model.joblib` cannot be loaded (e.g. scikit-learn version mismatch) the app retrains from `data/train.csv` in about a second.

## Streamlit Cloud
Put every file in the repo root, make sure `requirements.txt` contains `joblib` and `scikit-learn`, then reboot the app.

## Reproduce the results
```bash
pip install matplotlib
python generate_data.py      # synthetic data + family-level splits (seed 487)
python train_evaluate.py     # model selection (validation), baseline vs model, plots, metrics.json
python input_tests.py        # invalid / missing / unsupported input tests
python make_report.py        # needs python-docx; rebuilds the Word report
```

## Files
| File | Purpose |
|---|---|
| app.py | Streamlit application |
| core.py | normalisation, input validation, baseline rules, model loading, analysis |
| generate_data.py | transparent synthetic generator; splits by template family |
| train_evaluate.py | training, baseline comparison, metrics, plots |
| data/ | train / val / test / challenge / final CSVs, split_summary.json |
| model/ | saved model + selected config |
| results/ | metrics.json, confusion matrices, per-family accuracy, error tables, input tests |

## Data note
All sentences are generated from templates written for this project (no patient data, no licensed data).
Labels follow the template family. Instructor review of the label definitions is required.

## AI-use disclosure
Code and report were drafted with Claude (Anthropic). The student must verify and edit the declaration in the report.
