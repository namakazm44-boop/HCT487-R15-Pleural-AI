"""Train TF-IDF + logistic regression, compare with keyword/negation baseline,
choose review threshold on VALIDATION, evaluate ONCE on held-out test families."""
import json, numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (classification_report, confusion_matrix, f1_score,
                             balanced_accuracy_score, accuracy_score)
import core

L = core.LABELS
tr, va, te, ch, fi = [pd.read_csv(f"data/{s}.csv") for s in ["train", "val", "test", "challenge", "final"]]
res = Path = None
out = {}

# model selection on validation: C and ngram range grid (kept tiny on purpose)
best, best_f1 = None, -1
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
grid = []
for cues in [False, True]:
  for C in [0.5, 1, 5, 20]:
    for ng in [(1, 1), (1, 2), (1, 3)]:
        pipe = core.build_pipeline(C=C, ngram=ng, use_cues=cues)
        pipe.fit(tr.text, tr.label)
        f1 = f1_score(va.label, pipe.predict(va.text), average="macro", labels=L)
        grid.append(dict(cue_features=cues, C=C, ngram=str(ng), val_macro_f1=round(f1, 4)))
        if f1 > best_f1:
            best_f1, best, best_cfg = f1, pipe, (C, ng, cues)
pd.DataFrame(grid).to_csv("results/model_selection_validation.csv", index=False)
print("best config", best_cfg, "val macro-F1", round(best_f1, 4))

# refit selected config on TRAIN only (val kept for threshold); final model = train only
model = best
# review threshold on validation: lowest threshold with accepted-accuracy >= 0.95 and coverage >= 0.8
proba_va = model.predict_proba(va.text); conf_va = proba_va.max(1); pred_va = model.classes_[proba_va.argmax(1)]
thr = 0.0
for t in np.arange(0.40, 0.96, 0.01):
    acc_mask = conf_va >= t
    if acc_mask.mean() < 0.80: break
    acc = (pred_va[acc_mask] == va.label.values[acc_mask]).mean()
    if acc >= 0.95: thr = float(round(t, 2)); break
if thr == 0.0: thr = 0.60
print("review threshold (set on validation):", thr)

def evaluate(df, name):
    y = df.label.values
    pm = model.predict(df.text)
    pb = np.array([core.rule_baseline(s) for s in df.text])
    r = {}
    for nm, p in [("model", pm), ("baseline", pb)]:
        r[nm] = dict(macro_f1=f1_score(y, p, average="macro", labels=L),
                     balanced_acc=balanced_accuracy_score(y, p), accuracy=accuracy_score(y, p),
                     report=classification_report(y, p, labels=L, output_dict=True, zero_division=0),
                     cm=confusion_matrix(y, p, labels=L).tolist())
    # bootstrap CI on macro-F1 difference
    rng = np.random.default_rng(0); diffs = []
    for _ in range(1000):
        idx = rng.integers(0, len(y), len(y))
        diffs.append(f1_score(y[idx], pm[idx], average="macro") - f1_score(y[idx], pb[idx], average="macro"))
    r["f1_diff_ci95"] = [float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5))]
    r["n"] = int(len(df)); r["class_counts"] = df.label.value_counts().to_dict()
    # by family
    fam = []
    for f, g in df.groupby("family"):
        fam.append(dict(family=f, n=len(g), label=g.label.iloc[0],
                        model_acc=float((model.predict(g.text) == g.label.values).mean()),
                        baseline_acc=float((np.array([core.rule_baseline(s) for s in g.text]) == g.label.values).mean())))
    r["by_family"] = fam
    # review-threshold behaviour
    pr = model.predict_proba(df.text); conf = pr.max(1)
    acc_m = conf >= thr
    r["review"] = dict(threshold=thr, coverage=float(acc_m.mean()),
                       acc_accepted=float((pm[acc_m] == y[acc_m]).mean()) if acc_m.any() else None,
                       acc_flagged=float((pm[~acc_m] == y[~acc_m]).mean()) if (~acc_m).any() else None)
    # error table
    err = df.assign(model_pred=pm, baseline_pred=pb, confidence=conf.round(3))
    err[(err.model_pred != err.label) | (err.baseline_pred != err.label)].to_csv(f"results/errors_{name}.csv", index=False)
    # confusion matrix plot
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.8))
    for a, nm in zip(ax, ["baseline", "model"]):
        cm = np.array(r[nm]["cm"]); a.imshow(cm, cmap="Blues")
        a.set_xticks(range(3)); a.set_yticks(range(3)); a.set_xticklabels(L); a.set_yticklabels(L)
        a.set_xlabel("Predicted"); a.set_ylabel("True")
        a.set_title(f"{'Keyword/negation baseline' if nm=='baseline' else 'TF-IDF + LR'}\nmacro-F1 {r[nm]['macro_f1']:.3f}", fontsize=10)
        for i in range(3):
            for j in range(3):
                a.text(j, i, cm[i, j], ha="center", va="center", color="white" if cm[i, j] > cm.max()/2 else "black")
    plt.tight_layout(); plt.savefig(f"results/confusion_{name}.png", dpi=160); plt.close()
    return r

out["test"] = evaluate(te, "test")
out["final"] = evaluate(fi, "final")
out["challenge"] = evaluate(ch, "challenge")
out["validation_macro_f1"] = best_f1; out["selected_config"] = dict(C=best_cfg[0], ngram=str(best_cfg[1]), use_cues=best_cfg[2])
out["review_threshold"] = thr; out["model_version"] = core.MODEL_VERSION
out["train_n"] = int(len(tr)); out["val_n"] = int(len(va))

# bar chart of per-family accuracy (test + challenge)
fams = pd.DataFrame(out["test"]["by_family"] + out["challenge"]["by_family"] + out["final"]["by_family"])
fig, ax = plt.subplots(figsize=(9, 4)); x = np.arange(len(fams))
ax.bar(x - 0.2, fams.baseline_acc, 0.4, label="Baseline"); ax.bar(x + 0.2, fams.model_acc, 0.4, label="TF-IDF + LR")
ax.set_xticks(x); ax.set_xticklabels(fams.family, rotation=60, ha="right", fontsize=8); ax.set_ylabel("Accuracy"); ax.set_ylim(0, 1.05); ax.legend()
ax.set_title("Accuracy per held-out template family"); plt.tight_layout(); plt.savefig("results/accuracy_by_family.png", dpi=160); plt.close()

joblib.dump(model, core.MODEL_PATH)
json.dump(out, open("results/metrics.json", "w"), indent=2, default=float)
json.dump(dict(C=best_cfg[0], ngram=list(best_cfg[1]), use_cues=best_cfg[2]), open("model/config.json", "w"))
for k in ["test", "challenge", "final"]:
    print(f"\n== {k} (n={out[k]['n']}) ==")
    for nm in ["baseline", "model"]:
        print(nm, "macroF1 %.3f  balAcc %.3f  acc %.3f" % (out[k][nm]["macro_f1"], out[k][nm]["balanced_acc"], out[k][nm]["accuracy"]))
    print("F1 diff 95% CI", [round(v, 3) for v in out[k]["f1_diff_ci95"]], " review:", out[k]["review"])
print(fams.round(2).to_string())
